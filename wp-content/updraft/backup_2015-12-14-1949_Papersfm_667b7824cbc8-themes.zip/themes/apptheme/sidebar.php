<?php
/**
 * The Sidebar containing the main widget areas.
 *
 * @package AppPresser Theme
 */
?>
	<div id="secondary" class="widget-area" role="complementary">
		<?php do_action( 'before_sidebar' ); ?>
	</div><!-- #secondary -->