/*
 * AppPresser javascript plugins
 * Combines scripts to reduce http requests
 *
 * @package AppPresser Theme
 * @since   1.0.0
 */

// @codekit-append ../js/fastclick.js

// @codekit-append ../js/bootstrap.min.js